#include<iostream>
#include<ctime>
#include<cstdlib>
#include<vector>
using namespace std;
void hello() //hello(): Greets the player and provides instructions for the Hangman game.
{
    string name;                                                                
    cout << "Enter your name here: \n";
    cin >> name;
    cout<< name << "! Welcome to the Hangman Guessing Game.\n";          
    /* The use of newline characters(\n) ensures that each message is displayed
    on a new line for better readability.*/
   /* The tiTLE characters(~~~~~~~~~)// create a visual separation between the greeting and the instructions, adding clarity to the message.*/
    cout << "~~~~~~~~~ \n";
    cout << "Instructions: Guess the secret word from your choice category before the stick figure is hung.\n";
}

void display_misses(int misses)            
/*This function displays the hangman figure based on the
number of misses(incorrect guesses) made by the player.
The implementation is based on the number of misses.*/
{
  if(misses==0)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==1)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==2)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==3)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t /|   | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==4)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t /|\\  | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==5)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t /|\\  | \n";
    cout<<"\t \t \t \t \t /    | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
  else if(misses==6)
  {
    cout<<"\t \t \t \t \t  +---+ \n";
    cout<<"\t \t \t \t \t  |   | \n";
    cout<<"\t \t \t \t \t  O   | \n";
    cout<<"\t \t \t \t \t /|\\  | \n";
    cout<<"\t \t \t \t \t / \\  | \n";
    cout<<"\t \t \t \t \t      | \n";
    cout<<"\t \t \t \t \t ========= \n";
  }
}

void end_game(string answer, string codeword)
/*end_game(string answer, string codeword) :
Displays the outcome of the game (win/lose) by comparing
the player's guess (answer) with the actual word (codeword).*/
{
  if(answer==codeword)
  {
  	cout<<"CORRECT! The word was *"<<codeword<<"*"<<endl;
    cout<<"HOORAY! You saved the stick figure from being hanged!\n";
    cout<<"CONGRATULATIONS!YOU WON :)\n";
    cout<<endl;
    cout<<endl;
  }
  else
  {
  	cout<<"Oh no! You have lost :(\n";
  	cout<<"Your word was *"<<codeword<<"*"<<endl;
  }
}

void display_status(vector<char> incorrect, string answer)
/*display_status(vector<char> incorrect, string answer): Displays the current game status,
showing the partially guessed word (answer) and the incorrect guesses stored in a vector (incorrect).*/
{
  cout<<endl;
  cout<<"Guess this:";
  for(int i = 0; i<answer.length(); i++)
  {
    cout<<answer[i]<<" ";
  }
  cout<<endl;
   cout<<"Incorrect Guesses: ";
  for(int i = 0; i<incorrect.size(); i++)
  {
    cout<<incorrect[i]<<" ";
  }
}

void gameanimal()             // Function to play the Hangman game with animal words
{
	string animal;// Declares a string variable named animal, which will hold the randomly selected animal word.
	string animal_codeword[]={"giraffe","hippopotamus","iguana","hamster","koala","cobra","horse","kangaroo","crocodile","elephant"}; 
   // Initializes an array animal_codeword with 10 animal words.These are the words that the player will try to guess.
  srand(time(NULL));                           
  // Seeds the random number generator with the current time. This ensures that the random numbers generated later are different each time the program is run.
 
 int animal_index=rand()%10;
  // int animal_index = rand() % 10;: Generates a random index between 0 and 9 (inclusive)to select a random animal word from the animal_codeword array.
  animal= animal_codeword[animal_index];
  // animal = animal_codeword[animal_index];: Assigns the randomly selected animal word from the animal_codeword array to the animal variable.
  string animal_answer(animal.length(),'_');    /*Creates a string animal_answer with the same length as the animal word, filled with underscores(_).
                                                  This string represents the current state of the word being guessed by the player.*/

  int misses = 0;   // Initializes a variable misses to keep track of the number of incorrect guesses made by the player.It starts at 0 because the player has not made any guesses yet.

  vector<char> incorrect;  // Declares a vector named incorrect to store the incorrect guesses made by the player.This vector will dynamically grow to accommodate the incorrect guesses.
  bool guess = false;//Initializes a boolean variable guess to false. This variable will be used to track whether the player's guess is correct or not.

  char letter;   //  Declares a character variable letter to store the player's guess
	 while(animal_answer!=animal&& misses < 7)
         // This is a while loop that continues as long as the animal_answer string is not equal to the animal word and the number of misses is less than 7.
         //  It controls the main game loop,
         //  ensuring that the game continues until the player either guesses the word correctly or reaches the maximum allowed number of misses.
  {
    display_misses(misses);    //Calls the display_misses() function to show the current state of the hangman figure based on the number of misses.
    display_status(incorrect, animal_answer);/* Calls the display_status() function to display the current game status, showing the partially guessed word and
                                               the incorrect guesses made so far.*/

    cout<<"\n\nPlease enter your guess: ";//Prints a prompt asking the player to enter their guess.
    cin>>letter;

    for(int i = 0; i<animal.length(); i++) // Starts a loop to iterate through each character of the animal word.
    {
      if(letter==animal[i])     //Checks if the player's guess (letter) matches the current character of the animal word at index i.
      {
        animal_answer[i] = letter; //If the guess is correct, updates the animal_answer string at index i with the guessed letter.
        guess = true;  //If the guess was correct (guess is true), prints a message indicating that the guess was correct.
      }
    }
    if(guess)     //If the guess was correct (guess is true), prints a message indicating that the guess was correct.
    {
      cout<<"\nCorrect!\n";
    }
    else        /*If the guess was incorrect, prints a message indicating that the guess was incorrect, adds the incorrect guess to the incorrect vector,
                  increments the misses counter, and updates the hangman figure.*/
    {
      cout<<"\nIncorrect!\n";
      incorrect.push_back(letter);
      misses++;
    }
    guess = false;    // Resets the guess variable to false for the next iteration of the loop.
  }
  end_game(animal_answer, animal);       /*Calls the end_game() function to check if the game is over(either the player has guessed the word correctly
  or exceeded the maximum number of misses) and display the outcome of the game.*/
			
	}
void gamesports()     // Function to play the Hangman game with sport words
	{
		string sport; //Declares a string variable named sport to store the randomly selected sport word.
		srand(time(NULL));//Seeds the random number generator using the current time to ensure different random values on each program run.
	string sport_codeword[] = {"basketball","badminton","football","volleyball","cricket","hockey","rugby","golf","tennis","boxing"};
    //Initializes an array sport_codeword containing sport-related words
	int sport_index=rand()%10;  // Generates a random index between 0 and 9 to select a word from the sport_codeword array
	string sport_answer(sport_codeword[sport_index].length(), '_');  /*Creates a string sport_answer initialized with underscores() equal to the length
    of the selected sport word. This string represents the partially guessed sport word.*/


	sport= sport_codeword[sport_index];//Assigns the selected sport word from sport_codeword to the sport variable.
  int misses = 0;
  vector<char> incorrect;// Declares a vector named incorrect to store incorrect guesses made by the player.
  bool guess = false;    
  char letter;
	 while(sport_answer != sport&& misses < 7) /*starts a while loop that continues as long as the sport_answer string is not equal to the
         sport word (meaning the word hasn't been fully guessed) and the number of misses is less than 7 (the maximum allowed misses).*/
  {
    display_misses(misses);
    display_status(incorrect, sport_answer);
    cout<<"\n\nPlease enter your guess: ";
    cin>>letter;

    for(int i = 0; i<sport.length(); i++)
    {
      if(letter==sport[i])
      {
        sport_answer[i] = letter;
        guess = true;
      }
    }
    if(guess)
    {
      cout<<"\nCorrect!\n";
    }
    else
    {
      cout<<"\nIncorrect!\n";
      incorrect.push_back(letter);
      misses++;
    }
    guess = false;
  }
  end_game(sport_answer, sport);	
	}
	
void gamecountries()                 // Function to play the Hangman game with country words
{
	string country;
    srand(time(NULL));
    string country_codeword[] = {"argentina", "bangladesh", "colombia", "denmark", "ethiopia", "germany", "hungary", "indonesia", "kyrgyzstan", "nigeria"};
    int country_index = rand() % 10;
    string country_answer(country_codeword[country_index].length(), '_');
    country = country_codeword[country_index];
  int misses = 0;
  vector<char> incorrect;
  bool guess = false;
  char letter;
	 while(country_answer!=country && misses < 7)
  {
    display_misses(misses);
    display_status(incorrect, country_answer);
    cout<<"\n\nPlease enter your guess: ";
    cin>>letter;
    for(int i = 0; i<country.length(); i++)
    {
      if(letter==country[i])
      {
        country_answer[i] = letter;
        guess = true;
      }
    }
    if(guess)
    {
      cout<<"\nCorrect!\n";
    }
    else
    {
      cout<<"\nIncorrect!\n";
      incorrect.push_back(letter);
      misses++;
    }
    guess = false;
  }
  end_game(country_answer, country);
}

using namespace std;
int main()
{/*The main() function is the entry point of the program.
It calls the hello() function to greet the player and provide instructions.
Then it enters a loop allowing the player to choose a category for the Hangman game.
Inside the loop, the player's choice determines which game function (gameanimal(), gamecountries(), or gamesports()) is called.
The loop continues until the player chooses to exit.*/
	hello();
	cout<<endl;
	cout<<endl;
	cout<<endl;
	for(int j=1; j<=10; j++)
	{
	int choice;
	cout<<"There are 3 categories. Select the category of your choice! To exit enter 4."<<endl;
	cout<<"1.Animals."<<endl;
	cout<<"2.Countries."<<endl;
	cout<<"3.Sports."<<endl;
	cout<<"4.Exit."<<endl;
	cout<<"Enter the number applicable to your choice!"<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:
			gameanimal();
			
			break;
		case 2:
			gamecountries();
			break;
		case 3:
			gamesports();
			break;
		case 4:
			j=11;
			break;
		}
		cout<<endl;
}
}
