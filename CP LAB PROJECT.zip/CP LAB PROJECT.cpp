#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

// Function to greet the player and display game instructions
void hello() {
    string name;
    cout << "Enter your name here: \n";
    cin >> name; // Get the player's name
    cout << name << "! Welcome to the Hangman Guessing Game.\n";
    cout << "~~~~~~~~~ \n";
    cout << "Instructions: Guess the secret word from your choice category before the stick figure is hung.\n";
}

// Function to display the hangman figure based on the number of misses
void display_misses(int misses) {
    if (misses == 0) {
        // Display initial hangman state with no misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 1) {
        // Display hangman state with 1 miss
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 2) {
        // Display hangman state with 2 misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 3) {
        // Display hangman state with 3 misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t /|   | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 4) {
        // Display hangman state with 4 misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t /|\\  | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 5) {
        // Display hangman state with 5 misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t /|\\  | \n";
        cout << "\t \t \t \t \t /    | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    } else if (misses == 6) {
        // Display hangman state with 6 misses
        cout << "\t \t \t \t \t  +---+ \n";
        cout << "\t \t \t \t \t  |   | \n";
        cout << "\t \t \t \t \t  O   | \n";
        cout << "\t \t \t \t \t /|\\  | \n";
        cout << "\t \t \t \t \t / \\  | \n";
        cout << "\t \t \t \t \t      | \n";
        cout << "\t \t \t \t \t ========= \n";
    }
}

// Function to end the game and display the final result
void end_game(string answer, string codeword) {
    if (answer == codeword) {
        // Display success message if the player guessed the word correctly
        cout << "CORRECT! The word was *" << codeword << "*" << endl;
        cout << "HOORAY! You saved the stick figure from being hanged!\n";
        cout << "CONGRATULATIONS! YOU WON :)\n";
        cout << endl;
        cout << endl;
    } else {
        // Display failure message if the player failed to guess the word
        cout << "Oh no! You have lost :(\n";
        cout << "Your word was *" << codeword << "*" << endl;
    }
}

// Function to display the current status of the guessed word and incorrect guesses
void display_status(char incorrect[], int incorrectCount, string answer) {
    cout << endl;
    cout << "Guess this: ";
    // Display the current state of the word being guessed
    for (int i = 0; i < answer.length(); i++) {
        cout << answer[i] << " ";
    }
    cout << endl;
    cout << "Incorrect Guesses: ";
    // Display the letters that have been guessed incorrectly
    for (int i = 0; i < incorrectCount; i++) {
        cout << incorrect[i] << " ";
    }
}

// Function to play the game with animal category
void gameanimal() {
    string animal;
    // Array of possible animal words
    string animal_codeword[] = {"giraffe", "hippopotamus", "iguana", "hamster", "koala", "cobra", "horse", "kangaroo", "crocodile", "elephant"};
    srand(time(NULL)); // Seed the random number generator with the current time
    int animal_index = rand() % 10; // Get a random index for selecting the animal word
    animal = animal_codeword[animal_index]; // Select the animal word
    string animal_answer(animal.length(), '_'); // Initialize the guessed word with underscores

    int misses = 0; // Counter for the number of incorrect guesses
    char incorrect[7]; // Array to store incorrect guesses
    int incorrectCount = 0; // Counter for the number of incorrect guesses
    bool guess = false; // Flag to check if the guessed letter is correct
    char letter; // Variable to store the guessed letter

    // Loop until the player guesses the word or exceeds the maximum number of incorrect guesses
    while (animal_answer != animal && misses < 7) {
        display_misses(misses); // Display the hangman figure
        display_status(incorrect, incorrectCount, animal_answer); // Display the current status of the guessed word and incorrect guesses

        cout << "\n\nPlease enter your guess: ";
        cin >> letter; // Get the guessed letter from the player

        // Check if the guessed letter is in the animal word
        for (int i = 0; i < animal.length(); i++) {
            if (letter == animal[i]) {
                animal_answer[i] = letter; // Update the guessed word with the correct letter
                guess = true; // Set the guess flag to true
            }
        }
        if (guess) {
            cout << "\nCorrect!\n";
        } else {
            cout << "\nIncorrect!\n";
            incorrect[incorrectCount] = letter; // Add the incorrect guess to the array
            incorrectCount++; // Increment the incorrect guess counter
            misses++; // Increment the misses counter
        }
        guess = false; // Reset the guess flag for the next round
    }
    end_game(animal_answer, animal); // End the game and display the result
}

// Function to play the game with sports category
void gamesports() {
    string sport;
    srand(time(NULL)); // Seed the random number generator with the current time
    // Array of possible sports words
    string sport_codeword[] = {"basketball", "badminton", "football", "volleyball", "cricket", "hockey", "rugby", "golf", "tennis", "boxing"};
    int sport_index = rand() % 10; // Get a random index for selecting the sport word
    string sport_answer(sport_codeword[sport_index].length(), '_'); // Initialize the guessed word with underscores

    sport = sport_codeword[sport_index]; // Select the sport word
    int misses = 0; // Counter for the number of incorrect guesses
    char incorrect[7]; // Array to store incorrect guesses
    int incorrectCount = 0; // Counter for the number of incorrect guesses
    bool guess = false; // Flag to check if the guessed letter is correct
    char letter; // Variable to store the guessed letter

    // Loop until the player guesses the word or exceeds the maximum number of incorrect guesses
    while (sport_answer != sport && misses < 7) {
        display_misses(misses); // Display the hangman figure
        display_status(incorrect, incorrectCount, sport_answer); // Display the current status of the guessed word and incorrect guesses
        cout << "\n\nPlease enter your guess: ";
        cin >> letter; // Get the guessed letter from the player

        // Check if the guessed letter is in the sport word
        for (int i = 0; i < sport.length(); i++) {
            if (letter == sport[i]) {
                sport_answer[i] = letter; // Update the guessed word with the correct letter
                guess = true; // Set the guess flag to true
            }
        }
        if (guess) {
            cout << "\nCorrect!\n";
        } else {
            cout << "\nIncorrect!\n";
            incorrect[incorrectCount] = letter; // Add the incorrect guess to the array
            incorrectCount++; // Increment the incorrect guess counter
            misses++; // Increment the misses counter
        }
        guess = false; // Reset the guess flag for the next round
    }
    end_game(sport_answer, sport); // End the game and display the result
}

// Function to play the game with countries category
void gamecountries() {
    string country;
    srand(time(NULL)); // Seed the random number generator with the current time
    // Array of possible country words
    string country_codeword[] = {"argentina", "bangladesh", "colombia", "denmark", "ethiopia", "germany", "hungary", "indonesia", "kyrgyzstan", "nigeria"};
    int country_index = rand() % 10; // Get a random index for selecting the country word
    string country_answer(country_codeword[country_index].length(), '_'); // Initialize the guessed word with underscores
    country = country_codeword[country_index]; // Select the country word
    int misses = 0; // Counter for the number of incorrect guesses
    char incorrect[7]; // Array to store incorrect guesses
    int incorrectCount = 0; // Counter for the number of incorrect guesses
    bool guess = false; // Flag to check if the guessed letter is correct
    char letter; // Variable to store the guessed letter

    // Loop until the player guesses the word or exceeds the maximum number of incorrect guesses
    while (country_answer != country && misses < 7) {
        display_misses(misses); // Display the hangman figure
        display_status(incorrect, incorrectCount, country_answer); // Display the current status of the guessed word and incorrect guesses
        cout << "\n\nPlease enter your guess: ";
        cin >> letter; // Get the guessed letter from the player

        // Check if the guessed letter is in the country word
        for (int i = 0; i < country.length(); i++) {
            if (letter == country[i]) {
                country_answer[i] = letter; // Update the guessed word with the correct letter
                guess = true; // Set the guess flag to true
            }
        }
        if (guess) {
            cout << "\nCorrect!\n";
        } else {
            cout << "\nIncorrect!\n";
            incorrect[incorrectCount] = letter; // Add the incorrect guess to the array
            incorrectCount++; // Increment the incorrect guess counter
            misses++; // Increment the misses counter
        }
        guess = false; // Reset the guess flag for the next round
    }
    end_game(country_answer, country); // End the game and display the result
}

// Main function to run the Hangman game and allow the player to choose categories
int main() {
    hello(); // Greet the player and display instructions
    cout << endl;
    cout << endl;
    cout << endl;

    // Loop to allow the player to play multiple rounds or exit
    for (int j = 1; j <= 10; j++) {
        int choice;
        // Display category options to the player
        cout << "There are 3 categories. Select the category of your choice! To exit enter 4." << endl;
        cout << "1. Animals." << endl;
        cout << "2. Countries." << endl;
        cout << "3. Sports." << endl;
        cout << "4. Exit." << endl;
        cout << "Enter the number applicable to your choice!" << endl;
        cin >> choice; // Get the player's choice

        // Switch case to handle the player's choice and start the corresponding game
        switch (choice) {
            case 1:
                gameanimal(); // Play the animal category game
                break;
            case 2:
                gamecountries(); // Play the countries category game
                break;
            case 3:
                gamesports(); // Play the sports category game
                break;
            case 4:
                j = 11;  // Exit the loop
                cout<<"THANKYOU FOR PLAYING!!";
                break;
        }
        cout << endl;
    }
}

